﻿async function getProxySettings() {
  return new Promise(resolve => {
    chrome.proxy.settings.get({ incognito: false }, config => { resolve(config); });
  });
}

async function fetchPublicIP() {
  try {
    const res = await fetch("https://api.ipify.org?format=json");
    const data = await res.json();
    return data.ip;
  } catch { return "Unable to fetch"; }
}

async function updateDisplay() {
  const config = await getProxySettings();
  document.getElementById("mode").textContent = config.value.mode || "Unknown";

  if (config.value.mode === "fixed_servers" && config.value.rules) {
    const rules = config.value.rules;
    if (rules.singleProxy) {
      const proxy = `${rules.singleProxy.scheme}://${rules.singleProxy.host}:${rules.singleProxy.port}`;
      document.getElementById("proxy").textContent = proxy;
    } else { document.getElementById("proxy").textContent = "(Multiple / custom)"; }
  } else if (config.value.mode === "pac_script" && config.value.pacScript) {
    document.getElementById("pac").textContent = config.value.pacScript.url || "(embedded PAC)";
  } else {
    document.getElementById("proxy").textContent = "None (system or direct)";
    document.getElementById("pac").textContent = "—";
  }

  const ip = await fetchPublicIP();
  document.getElementById("ip").textContent = ip;

  chrome.storage.local.get(["baselineIP"], result => {
    const baseline = result.baselineIP;
    const warningEl = document.getElementById("warning");
    if (!baseline || baseline === "Unknown") {
      chrome.storage.local.set({ baselineIP: ip });
      warningEl.textContent = "Baseline IP recorded.";
      chrome.action.setBadgeText({ text: "" });
    } else if (baseline !== ip) {
      warningEl.textContent = "⚠️ Warning: Traffic appears to be routed through a proxy!";
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "red" });
    } else {
      warningEl.textContent = "";
      chrome.action.setBadgeText({ text: "" });
    }
  });
}

document.getElementById("refresh").addEventListener("click", updateDisplay);
updateDisplay();