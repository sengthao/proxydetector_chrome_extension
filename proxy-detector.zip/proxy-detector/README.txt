Disclaimer:
Provided as is, where is. FREE forever. Use at your own risk. All users releases the programmer of all liabilities. You assumes all risks and etc. Designed for Chrome. By use, you agree to everything. You can borrow all the codes, copy, paste, distribute.. it doesn't matter to me. I just made it for a simple reason and to be shared with everyone who can find it to be useful. Seng Thao. 


Description and purpose below. 

This is just a small script that I made for Chrome. 
I needed to frequently check the proxy connections in Chrome when I'm browsing. 
This is because I sometimes set flags in Chrome through certain proxy to test websites. 
Also Windows does "really" track your public IP address. That's assigned by your ISP. 
For example if you try to find your "public IP address" in windows, it's kind of difficult. 

Open command prompt, type in: nslookup myip.opendns.com resolver1.opendns.com
And then you can see your public IP.
Your public IP is what everyone see you on the internet. 

If you use the commands: ipconfig or ipconfig /all
You only get your private IP. 

For example: 
In CMD prompt: "C:\Program Files\Google\Chrome\Application\chrome.exe" --proxy-server="socks5://127.0.0.1:9150"
When I set a flag to have Chrome use the Tor browser proxy, I like to know if it actually is going to the correction proxy and port. 
If I am going through the correction proxy, I can access onion sites and open/view them. (Anonymity is excluded though.)
Another example is if I'm running the Tor expert bundle service and I push the following proxy: 
"C:\Program Files\Google\Chrome\Application\chrome.exe" --proxy-server="socks5://127.0.0.1:9050"
Now I am connected through the expert bundle daemon. 
There are other uses too, if your browser was hijacked, your company is pushing you through a proxy for particular sites and many other reasons. 
More commonly, if you're use a VPN. Did your proxy change, IP change, what can websites you visit see your outside IP as? 
So to answer those many questions, I designed this small extension to use.
In Chrome's extensions, point to the folder. 
Unpack it to your chrome extension and pin it. 
Very simple to apply. 
To remove it, right click on the extension on your browser and select Remove from Chrome.
Delete the file folder where ever you saved (Desktop) and done. 

It was built to answer these questions as well:
The goal is to quickly find out if a proxy is being used.
Did your IP/proxy change?
Is a PAC (Proxy Auto-Configuration) file being used. This is commonly used in enterprises. 
If using a VPN, did the proxy change?
See the current mode that Chrome is in?
Display anonymizing service?
direct	Chrome connects to the internet directly (no proxy).
system	Chrome follows your computer’s system-level proxy settings.
auto_detect	Chrome is trying to automatically detect a proxy (WPAD).
pac_script	Chrome is using a Proxy Auto-Configuration (PAC) file.
fixed_servers	Chrome is using a manually set proxy server.
PAC Script: http://proxy.company.com/proxy.pac
Gives your external (public) IP address — the IP that websites see when you connect to them.
It detects potential proxy/VPN use or network rerouting — for example:
You connect to a VPN → IP changes → warning appears
You disconnect → IP returns to baseline → warning disappears
The extension can’t directly detect “VPN software,” but:
If your public IP suddenly changes (especially to another region),
And Chrome’s proxy mode changes to "system" or "fixed_servers",
it infers that a VPN, proxy, or similar rerouting method is active.

Summary Table
Detection Type	Example Output	How It Helps
Proxy Mode	direct, pac_script, fixed_servers	Know how Chrome is routing traffic
Proxy Host	proxy.example.com:8080	Identify manual proxy servers
PAC Script	http://proxy.company.com/proxy.pac	See if a PAC configuration is in use
Public IP	203.0.113.42	See your external address
Proxy/VPN Warning	⚠️ “Traffic appears to be routed through a proxy!”	Detect network rerouting
Network Change Detection	Baseline IP ≠ current IP	Detect new network / VPN connection

What it cannot detect
Just to be clear:
❌ It can’t see other apps’ traffic (only Chrome’s proxy settings).
❌ It can’t read encrypted VPN configurations directly.
❌ It doesn’t monitor which specific websites use which proxies (Chrome doesn’t expose that).


I hope this helps you. 
Sincerely, 
Seng Thao
www.thugon.com
2025
